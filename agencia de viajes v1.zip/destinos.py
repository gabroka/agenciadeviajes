'''

Crear, leer, modificar y eliminar destinos turísticos.


'''