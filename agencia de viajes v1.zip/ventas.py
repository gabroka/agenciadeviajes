'''

Simular compras y reservas de viajes


'''