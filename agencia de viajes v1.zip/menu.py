'''

Menu de opciones e interaccion con el usuario

'''