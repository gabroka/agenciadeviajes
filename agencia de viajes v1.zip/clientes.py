'''

Crear, leer, modificar y eliminar clientes.


'''